package com.testinium.exception;

public class TestiniumWarningException extends RuntimeException {

    public TestiniumWarningException(String errorMessage) {
        super(errorMessage);
    }
}
